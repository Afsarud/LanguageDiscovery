﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Language.Discovery.Entity;
using Language.Discovery.PhraseCategoryService;
using System.Web.Script.Serialization;
using Language.Discovery.PaletteService;
using Language.Discovery.UserService;
using Language.Discovery.SchoolService;
using System.Text;
using System.Web.UI.HtmlControls;
using System.Configuration;
using System.Data;
using System.IO;
using System.Threading;


namespace Language.Discovery
{
	public partial class SendMessage : System.Web.UI.Page
	{
		
		private int m_SentenceRowPerPage = Convert.ToInt32(ConfigurationManager.AppSettings["SentenceRowsPerPage"]);
		private int m_WordRowPerPage = Convert.ToInt32(ConfigurationManager.AppSettings["WordRowsPerPage"]);
        private int m_SearchHistoryLimit = Convert.ToInt32(ConfigurationManager.AppSettings["SearchHistoryLimit"]);
        private bool m_IsCategoryTriggered = false;
        private bool m_IsBack = false;
        private bool m_IsSearchAll = false;
        private string m_SearchText = string.Empty;

        private string Keyword
		{
			get
			{
				string key = "";
				if (ViewState["Keyword"] != null)
					key = ViewState["Keyword"].ToString();
				return key;
			}
			set
			{
				ViewState["Keyword"] = value;
			}
		}

		private List<PhraseCategoryContract> CategoryList
		{
			get
			{
				List<PhraseCategoryContract>  list = null;
				if (ViewState["CategoryList"] != null)
					list = (List<PhraseCategoryContract>)ViewState["CategoryList"];
				return list;
			}
			set
			{
				ViewState["CategoryList"] = value;
			}
		}

		private List<TopCategoryContract> TopCategoryList
		{
			get
			{
				List<TopCategoryContract> list = null;
				if (ViewState["TopCategoryList"] != null)
					list = (List<TopCategoryContract>)ViewState["TopCategoryList"];
				return list;
			}
			set
			{
				ViewState["TopCategoryList"] = value;
			}
		}


        private List<SearchDTO> SentenceSearchHistoryList
        {
            get
            {
                List<SearchDTO> list = new List<SearchDTO>();
                if (ViewState["SentenceSearchHistoryList"] != null)
                    list = (List<SearchDTO>)ViewState["SentenceSearchHistoryList"];
                else
                    ViewState["SentenceSearchHistoryList"] = list;

                return list;
            }
            //set
            //{
            //    ViewState["SearchHistoryList"] = value;
            //}
        }

        private List<SearchDTO> WordSearchHistoryList
        {
            get
            {
                List<SearchDTO> list = new List<SearchDTO>();
                if (ViewState["WordSearchHistoryList"] != null)
                    list = (List<SearchDTO>)ViewState["WordSearchHistoryList"];
                else
                    ViewState["WordSearchHistoryList"] = list;

                return list;
            }
            //set
            //{
            //    ViewState["SearchHistoryList"] = value;
            //}
        }

        protected int WordSearchHistoryListIndex
        {
            get
            {
                int index = -1;
                if (ViewState["WordSearchHistoryListIndex"] != null)
                    index = (int)ViewState["WordSearchHistoryListIndex"];

                return index;
            }
            set
            {
                ViewState["WordSearchHistoryListIndex"] = value;
            }
        }

        protected int SentenceSearchHistoryListIndex
        {
            get
            {
                int index = -1;
                if (ViewState["SentenceSearchHistoryListIndex"] != null)
                    index = (int)ViewState["SentenceSearchHistoryListIndex"];

                return index;
            }
            set
            {
                ViewState["SentenceSearchHistoryListIndex"] = value;
            }
        }

        private bool IsSearchFromHistory
        {
            get
            {
                bool res = false;
                if (ViewState["IsSearchFromHistory"] != null)
                    res = (bool)ViewState["IsSearchFromHistory"];

                return res;
            }
            set
            {
                ViewState["IsSearchFromHistory"] = value;
            }
        }

        protected override void InitializeCulture()
		{
			if (SessionManager.Instance.UserProfile == null)
			{
				Response.Redirect("~/Logout");
				return;
			}
			UICulture = SessionManager.Instance.UserProfile.NativeLanguage;

			base.InitializeCulture();
		}
		protected void Page_Load(object sender, EventArgs e)
		{
			try
			{

				if (!IsPostBack)
				{
                    hdnIsFirstLogin.Value = (SessionManager.Instance.UserProfile.LastLogin == DateTime.MinValue) ? "1" : "0";
                    string dst = Request.QueryString["dst"];
					this.Keyword = Request.QueryString["k"];
					
					if (!string.IsNullOrEmpty(dst) && dst == "1")
					{
						if (new UserClient().UpdateUserDontShowNewTab(SessionManager.Instance.UserProfile.UserID, true))
							SessionManager.Instance.UserProfile.DontShowNewTab = true;
					}
					PopulateDropDownList();
					LoadSenderDetails();
					LoadToDetails();
					CreateSuggestion();
					hdnNativeLanguageCode.Value = SessionManager.Instance.UserProfile.NativeLanguage;
					hdnLearningLanguageCode.Value = SessionManager.Instance.UserProfile.LearningLanguage;
                    imgBack.Visible = false;
                    imgForward.Visible = false;
                    SetOptions();
                    SearchAll();
                    hdnIsDemo.Value = Convert.ToByte(SessionManager.Instance.UserProfile.IsDemo).ToString(); 
					 //string script = "$(function () {";
					 //script += "$('#tabs').tabs();});";
					ScriptManager.RegisterStartupScript(this, this.GetType(), "ClearSessionStoragescript", "ClearSessionStorage();", true);
				}
				this.Form.DefaultButton = imgSearchSentence.UniqueID;
				this.Form.DefaultFocus = txtSearchSentence.UniqueID;
				if (SessionManager.Instance.UserProfile.IsDemo && SessionManager.Instance.SchoolProfile.IsRobot)
				{
					txtSearchSentence.Enabled = false;
				}
			}
			catch (Exception)
			{

				throw;
			}

		}

		private void SetOptions()
		{
			if (SessionManager.Instance.UserProfile.NativeLanguage == "ja-JP" || SessionManager.Instance.UserProfile.NativeLanguage == "zh-CN")
			{
				//data-on="info" data-off="danger" data-on-label="ENG" data-off-label="JP">
				//divRomanji.Visible = false;
				//divorder.Attributes["data-on"] = "danger";
				//divorder.Attributes["data-off"] = "info";
				//divorder.Attributes["data-on-label"] = "JP";
				//divorder.Attributes["data-off-label"] = "EN";

				//divShowTranslation.Attributes["data-on-label"] = "<i class='icon-ok icon-white'><img src='../Images/en-US.png' style='width:16x;height;16px;'/></i>";
				//divShowTranslation.Attributes["data-off-label"] = "<i class='icon-ok icon-white'><img src='../Images/ja-JP.png' style='width:16x;height;16px;'/></i>";
				chkLanguageOrder.Checked = true;
				divRomanji.Visible = true;
				chkSecondary.Checked = false;
				chkSecondary.Attributes.Add("disabled", "disabled");
			}
			else
			{
				divRomanji.Visible = true;
				chkLanguageOrder.Checked = false ; 
			}

			if (SessionManager.Instance.UserProfile.IsOptionUpdated)
			{
				chkSequence.Checked = SessionManager.Instance.UserProfile.SequenceOptionFlag;
				chkNative.Checked = SessionManager.Instance.UserProfile.NativeOptionFlag;
				chkSecondary.Checked = SessionManager.Instance.UserProfile.SubLanguageOptionFlag;
				chkSubLanguage2.Checked = SessionManager.Instance.UserProfile.SubLanguage2OptionFlag;
			}
			else
			{
				chkSequence.Checked = SessionManager.Instance.SchoolProfile.ShowPhraseOrder;
				chkNative.Checked = SessionManager.Instance.SchoolProfile.ShowNativeLanguage;
				chkSubLanguage2.Checked = SessionManager.Instance.SchoolProfile.ShowSubLanguage2;
			}
			
			//if (!SessionManager.Instance.SchoolProfile.ShowPhraseOrder)
			//{
			//    chkSequence.Checked = SessionManager.Instance.SchoolProfile.ShowPhraseOrder;
			//    chkSequence.Attributes.Add("disabled", "disabled");
			//}
			//if (!SessionManager.Instance.SchoolProfile.ShowNativeLanguage)
			//{
			//    chkNative.Checked = SessionManager.Instance.SchoolProfile.ShowNativeLanguage;
			//    chkNative.Attributes.Add("disabled", "disabled");
			//}
			//if (SessionManager.Instance.SchoolProfile.ShowSubLanguage2)
			//{
			//    chkSubLanguage2.Checked = SessionManager.Instance.SchoolProfile.ShowSubLanguage2;
			//    //chkNative.Attributes.Add("disabled", "disabled");
			//}

			//chkLanguageOrder.Checked = (SessionManager.Instance.SchoolProfile.DefaultLanguageOrder != SessionManager.Instance.UserProfile.LearningLanguage);
				
		}

		protected void ddlCategory_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				m_IsCategoryTriggered = true;
				TriggerCategorySearch();
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		private void TriggerCategorySearch()
		{
			if (hdnIsDropDownChangeFromClient.Value == "1")
			{
				hdnIsDropDownChangeFromClient.Value = "0";
				ScriptManager.RegisterStartupScript(this, this.GetType(), "dropdownchange" + Guid.NewGuid().ToString().Replace("-", ""), "ChangeTheIsDropDownChange('0');", true);
				return;
			}


			//if (rdoCriteriaList.SelectedValue == "0")//All
			//{
			//    SearchWords();
			//    SearchSentence();
			//}
			//else if (rdoCriteriaList.SelectedValue == "1")//Word
			//{
			//    UpdatePanel2.Triggers.RemoveAt(1);
			//    SearchWords();
				//SearchSentence();
			//}

		    hdnwordpage.Value = "1";
            hdnsentencepage.Value = "1";

            SearchAll();
			ScriptManager.RegisterStartupScript(this, this.GetType(), "addallwords_" + Guid.NewGuid().ToString().Replace("-", ""), "AppendCircleButton();", true);

		}

		private void LoadSenderDetails()
		{
			try
			{
				UserContract user = null;
				string json = new UserClient().GetUserDetails(SessionManager.Instance.UserProfile.UserID);
				if (!string.IsNullOrEmpty(json))
				{
				   user = new JavaScriptSerializer().Deserialize<UserContract>(json);
				   //lblFromName.Text = user.FirstName;
				   //imgFrom.ImageUrl = "../Images/Avatar/" + user.Avatar;
				}

			}
			catch (Exception ex)
			{
			   throw;
			}
		}

		private void LoadToDetails()
		{
			try
			{
				string shouldgetdefault = Request.QueryString["du"];
				UserClient client = new UserClient();
				if (!string.IsNullOrEmpty(shouldgetdefault) && shouldgetdefault == "1")
				{
					int[] items = new int[]{};
					
					string js = client.DiscoverNewFriends2(items,0, string.Empty, SessionManager.Instance.UserProfile.UserID);
					JavaScriptSerializer us = new JavaScriptSerializer();
					List<UserSearchContract> usList = us.Deserialize<List<UserSearchContract>>(js);

					if (usList == null)
					{
						Response.Redirect("~/Student/Home");
					}

					string grp = string.Join(",", usList.Select(x => x.UserID).ToArray());
					
					ViewState["UserTo"] = grp;
					lblToName.Text = "Group";
					imgTo.ImageUrl = "../Images/groupavatar.png";
					lstRecipient.DataSource = usList;
					lstRecipient.DataTextField = "UserName";
					lstRecipient.DataValueField = "UserID";
					lstRecipient.DataBind();
					
					return;
				}
				if (!string.IsNullOrEmpty(Request.QueryString["grp"]))
				{
					ViewState["UserTo"] = Request.QueryString["grp"];
					lblToName.Text = "Group";
					imgTo.ImageUrl = "../Images/groupavatar.png";
					List<UserContract> list = null;
					if (ViewState["UserTo"] != null)
					{
						list = new List<UserContract>(ViewState["UserTo"].ToString().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(s => new UserContract() { UserID = int.Parse(s) }));
					}
					

					UserContract[] usl = client.GetUserByIDs(list.ToArray());
					lstRecipient.DataSource = usl;
					lstRecipient.DataTextField = "UserName";
					lstRecipient.DataValueField = "UserID";
					lstRecipient.DataBind();
					return;

				}
				UserContract user = null;
				long userid = !string.IsNullOrEmpty(Request.QueryString["to"]) ? Convert.ToInt64(Request.QueryString["to"]) : 0;
				if (userid == 0)
					return;

				string json = new UserClient().GetUserDetails(userid);
				if (!string.IsNullOrEmpty(json))
				{
					user = new JavaScriptSerializer().Deserialize<UserContract>(json);
					List<UserContract> list = new List<UserContract>();
					if (user != null)
					{
						list.Add(user);
						lstRecipient.DataSource = list;
						lstRecipient.DataTextField = "UserName";
						lstRecipient.DataValueField = "UserID";
						lstRecipient.DataBind();
					}
					//lblToName.Text = user.FirstName;
					//imgTo.ImageUrl = "../Images/Avatar/" + user.Avatar;
				}
				
			}
			catch (Exception ex)
			{
				throw;
			}
		}

		private void PopulateDropDownList()
		{
			try
			{
				PhraseCategoryServiceClient pclient = new PhraseCategoryServiceClient();
				string json = pclient.GetPhraseCategory(SessionManager.Instance.UserProfile.NativeLanguage, SessionManager.Instance.UserProfile.LevelID, SessionManager.Instance.UserProfile.SchoolID);

				List<PhraseCategoryContract> plist = new JavaScriptSerializer().Deserialize<List<PhraseCategoryContract>>(json);
				CategoryList = plist; 
				//plist.Insert (0,new PhraseCategoryContract() { PhraseCategoryID = 0, PhraseCategoryCode = "[All]" });
				//ddlCategory.DataSource = plist;
				//ddlCategory.DataTextField = "PhraseCategoryCode";
				//ddlCategory.DataValueField = "PhraseCategoryID";
				//ddlCategory.DataBind();

				TopCategoryContract[] tcats = pclient.GetTopCategoryList(SessionManager.Instance.UserProfile.NativeLanguage);

				if (tcats != null)
				{
					List<TopCategoryContract> lcats = tcats.ToList();
                    //lcats.Insert(0, new TopCategoryContract() { TopCategoryHeaderID = 0, TopCategoryName = "[All]" });
                    //ddlTopCategory.DataSource = lcats;
                    //ddlTopCategory.DataTextField = "TopCategoryName";
                    //ddlTopCategory.DataValueField = "TopCategoryHeaderID";
                    //ddlTopCategory.DataBind();
                    TopCategoryContract talk = lcats.Find(x => x.IsTalk);
                    if (talk != null)
                        lcats.Remove(talk);

					TopCategoryList = lcats; 
					rptTopCategory.DataSource = lcats;
					rptTopCategory.DataBind();
				}

				int startrandom = 1;
				if (SessionManager.Instance.UserProfile.IsDemo && SessionManager.Instance.SchoolProfile.IsRobot)
				{
					plist.RemoveAll(x => (x.IsDemo == false && x.DisplayInUI == false) || (x.IsDemo == true && x.DisplayInUI == false));
					ScriptManager.RegisterStartupScript(this, this.GetType(), "DisableCategoryscript", "DisableCategory();", true);
					startrandom = 0;
					this.Keyword = string.Empty;
					if (plist.Count == 0)
						return;
				}
				else
				{
					plist.RemoveAll(x => (x.IsDemo == true));
				}

				Random next = new Random();
                int index = -1;
                if(plist.Count > 0)
                    index = next.Next(startrandom, plist.Count == 1 ? 1 : plist.Count - 1);
				//ddlCategory.SelectedIndexChanged -= ddlCategory_SelectedIndexChanged;
				if (string.IsNullOrEmpty(this.Keyword))
				{
					if (SessionManager.Instance.UserProfile.IsDemo)
					{
                        TopCategoryContract top = null;
                        if(index > -1)
                            top = TopCategoryList.Find(x => x.TopCategoryHeaderID == plist[index].TopCategoryHeaderID );
						if (top != null)
						{
							hdnCategory.Value = plist[index].PhraseCategoryID.ToString();
							ScriptManager.RegisterStartupScript(this, this.GetType(), "InitializeCategoryscript",
								string.Format("InitializeCategory('{0} > {1}');",
									top == null ? string.Empty : top.TopCategoryName, plist[index].PhraseCategoryCode),
								true);
						}
						else
						{
							hdnCategory.Value = "0";
							top = TopCategoryList.Find(x => x.IsMain == true);
                            TopCategoryContract top1 = null;
                            if (top == null)
                            {
                                top1 = TopCategoryList.Find(x => x.IsDefault == true);
                                ScriptManager.RegisterStartupScript(this, this.GetType(), "InitializeCategoryscript", string.Format("InitializeCategory('{0}');", top1 == null ? string.Empty : top1.TopCategoryName), true);
                            }
                            else
                            {
                                ScriptManager.RegisterStartupScript(this, this.GetType(), "InitializeCategoryscript", string.Format("InitializeCategory('{0} > {1}');", top == null ? string.Empty : top.TopCategoryName, "[All]"), true);
                            }
							//ScriptManager.RegisterStartupScript(this, this.GetType(), "InitializeCategoryscript", string.Format("InitializeCategory('{0} > {1}');", top == null ? string.Empty : top.TopCategoryName, "[All]"), true);
						}
                        if (top != null)
                            hdnTopCategoryName.Value = top.TopCategoryName;
					}
					else
					{
						TopCategoryContract top = TopCategoryList.Find(x => x.IsDefault == true);
						if (top != null)
						{
							var cats = CategoryList.FindAll(x => x.TopCategoryHeaderID.Equals(top.TopCategoryHeaderID));
						    if (cats.Count > 0 && cats.Count == 1)
						    {
						        hdnCategory.Value = cats[0].PhraseCategoryID.ToString();
						        ScriptManager.RegisterStartupScript(this, this.GetType(), "InitializeCategoryscript",
						            string.Format("InitializeCategory('{0}');", top == null ? string.Empty : top.TopCategoryName
						                ),
						            true);
						    }
                            else if (CategoryList.Count > 0)
						    {
                                //hdnCategory.Value = CategoryList[0].PhraseCategoryID.ToString();
                                hdnCategory.Value = "0";
                                top = TopCategoryList.Find(x => x.IsMain == true);
                                ScriptManager.RegisterStartupScript(this, this.GetType(), "InitializeCategoryscript",
                                string.Format("InitializeCategory('{0} > {1}');", top == null ? string.Empty : top.TopCategoryName, "[All]"),
                                true);

						    }

						}
                        if (top != null)
                            hdnTopCategoryName.Value = top.TopCategoryName;
                    }
                }
				else
				{
					hdnCategory.Value = "0";
					TopCategoryContract top = TopCategoryList.Find(x => x.IsMain == true);
				    TopCategoryContract top1 = null;
				    if (top == null)
				    {
                        top1 = TopCategoryList.Find(x => x.IsDefault == true);
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "InitializeCategoryscript", string.Format("InitializeCategory('{0}');", top1 == null ? string.Empty : top1.TopCategoryName), true);
                        if (top1 != null)
                            hdnTopCategoryName.Value = top1.TopCategoryName;
                    }
				    else
				    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "InitializeCategoryscript", string.Format("InitializeCategory('{0} > {1}');", top == null ? string.Empty : top.TopCategoryName, "[All]"), true);
                        if (top != null)
                            hdnTopCategoryName.Value = top.TopCategoryName;
                    }


                }

				//if (!string.IsNullOrEmpty(hdnTopCategory.Value))
				//{
				//    var cats = CategoryList.FindAll(x => x.TopCategoryHeaderID.Equals(Convert.ToInt32(hdnTopCategory.Value)));
				//    if (cats.Count > 0 && cats.Count == 1)
				//    {
				//        hdnCategory.Value = cats[0].PhraseCategoryID.ToString();
				//    }

				//}

				//ddlCategory.SelectedIndexChanged += ddlCategory_SelectedIndexChanged;



			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		private int CreateWordList()
		{
			try
			{
		
				PaletteServiceClient pclient = new PaletteServiceClient();
				int virtualcount = 0;
				//string json = pclient.SearchWord(new SearchDTO() { SchoolID= SessionManager.Instance.UserProfile.SchoolID, CategoryID = Convert.ToInt64( ddlCategory.SelectedValue ), Keyword = txtSearchSentence.Text, PageNumber = Convert.ToInt32(hdnwordpage.Value), RowsPerPage = m_WordRowPerPage }, out virtualcount);
				//string json = pclient.SearchWord(new SearchDTO() { SchoolID = SessionManager.Instance.UserProfile.SchoolID, CategoryID = 0, Keyword = txtSearchSentence.Text, PageNumber = Convert.ToInt32(hdnwordpage.Value), RowsPerPage = m_WordRowPerPage }, out virtualcount);
			    SearchDTO dto = new SearchDTO()
			    {
			        SchoolID = SessionManager.Instance.UserProfile.SchoolID,
			        CategoryID = txtSearchSentence.Text.Length == 0 ? Convert.ToInt64(hdnCategory.Value) : 0,
			        Word = txtSearchSentence.Text,
			        Keyword = txtSearchSentence.Text,
			        PageNumber = Convert.ToInt32(hdnwordpage.Value),
			        RowsPerPage = m_WordRowPerPage,
			        UserID = SessionManager.Instance.UserProfile.UserID,
			        TopCategoryHeaderID = txtSearchSentence.Text.Length == 0 ? Convert.ToInt32(hdnTopCategory.Value) : 0,
                    TopCategoryName = hdnTopCategoryName.Value
			        //TopCategoryHeaderID = Convert.ToInt32(ddlCategory.SelectedValue) == 0 ? Convert.ToInt32(ddlTopCategory.SelectedValue) : 0
			    };

                if (!string.IsNullOrEmpty(this.Keyword) && string.IsNullOrEmpty(txtSearchSentence.Text) && hdnCategory.Value == "0")
                {
                    hdnCategory.Value = "0";
                    dto.CategoryID = 0;
                    if (!m_IsCategoryTriggered)
                    {
                        dto.Word = this.Keyword.Replace("&#39;", "'");
                        dto.Keyword = this.Keyword.Replace("&#39;", "'");
                    }
                }
                if (IsSearchFromHistory)
                {
                    dto = GetSearchWordDto();
                    hdnwordpage.Value = dto.PageNumber.ToString();
                    hdnTopCategory.Value = dto.TopCategoryHeaderID.ToString();
                    hdnCategory.Value = dto.CategoryID.ToString();
                    m_SearchText = dto.Word;
                    hdnTopCategoryName.Value = dto.TopCategoryName;
                }
                else
                {
                    AddSearchWordList(dto);
                    
                }
                
                string json = pclient.SearchWord(dto, out virtualcount);
				
				//multiple category
				//if (dto.CategoryID == 0)
				//{
				//    foreach (ListItem item in ddlCategory.Items)
				//    {
				//        if (item.Value == "0")
				//            continue;

				//        dto.CategoryIDs += item.Value + ",";
				//    }
				//}
				//else
				//{
				//    dto.CategoryIDs = ddlCategory.SelectedValue;
				//}

				List<WordContract> list = new JavaScriptSerializer().Deserialize<List<WordContract>>(json);

				string words = string.Empty;

				HtmlGenericControl parentul = new HtmlGenericControl("ul");
				parentul.Attributes.Add("class", "items2");

				var pnativelist = list.FindAll(x => x.LanguageCode.Equals(SessionManager.Instance.UserProfile.NativeLanguage)).ToList();
				var plearninglist = list.FindAll(x => x.LanguageCode.Equals(SessionManager.Instance.UserProfile.LearningLanguage)).ToList();
				var psubnativelist = list.FindAll(x => x.LanguageCode.Equals(SessionManager.Instance.UserProfile.SubNativeLanguage)).ToList();
				var psubnative2list = list.FindAll(x => x.LanguageCode.Equals(SessionManager.Instance.UserProfile.SubNativeLanguage2)).ToList();

				foreach (WordContract wc in pnativelist)
				{
					HtmlGenericControl li = new HtmlGenericControl("li");

					string subnative2word = string.Empty;
					string subnative2code = string.Empty;

					var sub2 = psubnative2list.Find(x => x.WordMapID.Equals(wc.WordMapID));

					if (sub2 != null)
					{
						subnative2word = sub2.Word;
						subnative2code = sub2.LanguageCode.Substring(0, 2);
					}


					int count = 1;
					string dimage = "data-image='../Content/images/" + wc.ImageFile + "' ";
					if (string.IsNullOrEmpty(wc.ImageFile))
						dimage = string.Empty;

                    var learn = plearninglist.Find(x => x.WordMapID.Equals(wc.WordMapID));
                    					
                    var wordsoundfile = string.Empty;
                    if (learn != null)
                    {
                        wordsoundfile = learn.SoundFile;
                    }
                    words = string.Format("<span id='{0}' class='firstword' data-lang='{1}' data-switchword='{2}' data-word='{3}' {4} data-sound='{5}'>", "divspanword" + wc.WordID.ToString(), wc.LanguageCode, wc.LanguageCode.Substring(0, 2) == subnative2code ? subnative2word : "", wc.Word, dimage, "../Content/Sound/" + wordsoundfile) + wc.Word + "</span>" + "<br/>";
                    if (learn != null)
					{
						string cl = "secondword";
						words += string.Format("<span id='{0}' class='{1}' data-lang='{2}' data-switchword='{3}' data-word='{4}' {5} data-sound='{6}'>", "divspanword" + learn.WordID.ToString(), cl, learn.LanguageCode, learn.LanguageCode.Substring(0, 2) == subnative2code ? subnative2word : "", learn.Word, dimage, "../Content/Sound/" + wc == null ? string.Empty : wc.SoundFile) + learn.Word + "</span>" + "<br/>";
					}

					var sub = psubnativelist.Find(x => x.WordMapID.Equals(wc.WordMapID));
					if (sub != null)
					{
						string cl = "thirdword";
						words += string.Format("<span id='{0}' class='{1}'>", "divspan" + sub.WordID.ToString(), cl) + sub.Word + "</span>" + "<br/>";
					}

					foreach (string lang in SessionManager.Instance.UserProfile.OtherLanguages)
					{

						var otherlanguage = list.FindAll(x => x.LanguageCode.Equals(lang)).ToList();
						if (otherlanguage != null)
						{
							if (learn == null)
								learn = wc;

							var otherword = otherlanguage.Find(x => x.WordMapID.Equals(learn == null ? wc.WordMapID : learn.WordMapID));
							if (otherword != null)
							{
								string cl = "otherword";
								words += string.Format("<span id='{0}' class='{1}' style='display:none;' data-lang='{2}' data-switchword='{3}' data-word='{4}' {5} data-sound='{6}'>", "divspanword" + otherword.WordID.ToString(), cl, otherword.LanguageCode, otherword.LanguageCode.Substring(0, 2) == subnative2code ? subnative2word : "", otherword.Word, dimage, "../Content/Sound/" + otherword.SoundFile) + otherword.Word + "</span>";                                //sentence2ordinal += otherword.Ordinal.ToString() + ",";
							}

						}
					}

					string datasound = string.Empty;
					if (learn != null)
						datasound = "data-sound='../Content/sound/" + learn.SoundFile + "' ";


					string div = string.Format("<div id=\"div{0}\" class=\"screenshot wordbox\" style=\"border:1px solid black;text-align:center;background-color:white;cursor:pointer;position:relative;\" data-isword=\"true\" onclick=\"wordClick('div{0}', false, false);\" data-image=\"../Content/images/" + wc.ImageFile + "\" {2} >" +
						(wc.ImageFile.Length > 0 ? "<a class='gallery' href='../Content/Images/" + wc.ImageFile + "'> <img class='imgPicture' src=\"../Images/showimage.png\" style=\"width:15px; height:15px; position:absolute;top:-5px;left:-5px;\" onclick='ShowPicture(event)'/></a>" : string.Empty) +
								"{1}" +
								"</div>", wc.WordID.ToString() + (learn != null ? learn.WordID.ToString() : string.Empty) + (sub == null ? string.Empty : sub.WordID.ToString()), words, datasound);
					li.InnerHtml = div;
					parentul.Controls.Add(li);
				}
				divWordContainer.Controls.Add(parentul);

				return virtualcount;

			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		private void CreateWordListBackup()
		{
			try
			{
				PaletteServiceClient pclient = new PaletteServiceClient();

				string json = "";//pclient.SearchWord(new SearchDTO() { Keyword=txtSearchSentence.Text, PageNumber = 1, RowsPerPage = 10 }, out );
				List<WordContract> list = new JavaScriptSerializer().Deserialize<List<WordContract>>(json);

				string words = string.Empty;

				HtmlGenericControl parentul = new HtmlGenericControl("ul");
				parentul.Attributes.Add("class", "items2");

				

				foreach (WordContract wc in list)
				{
					HtmlGenericControl li = new HtmlGenericControl("li");

					int count = 1;
					words = string.Format("<span id='{0}' class='firstword'>", "divspanword" + wc.WordID.ToString() ) + wc.Word + "</span>" + "<br/>";
					foreach (WordContract w in wc.WordList)
					{
						count++;
						if (count == 2)
						{
							string cl = "secondword";
							words += string.Format("<span id='{0}' class='{1}'>", "divspanword" + w.WordID.ToString() + count.ToString(),cl) + w.Word + "</span>" + "<br/>";
						}
						if (count == 3)
						{
							string cl = "thirdword";
							words += string.Format("<span id='{0}' class='{1}'>", "divspan" +  w.WordID.ToString() + count.ToString(),cl) + w.Word + "</span>" + "<br/>";
						}
					}


					string div = string.Format("<div id=\"div{0}\" class=\"screenshot\" style=\"border:1px solid black;text-align:center; display:inline-block;background-color:white;cursor:pointer;width:200px;\" ondblclick=\"worddblClick('div{0}', false);\" data-image=\"http://localhost:50835/Content/images/" + wc.ImageFile + "\" >" +
								"{1}" +
						"</div>", wc.WordID,  words);
					li.InnerHtml = div;
					parentul.Controls.Add(li);
				}
				divWordContainer.Controls.Add(parentul);

			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		private void CreateSuggestion()
		{


			PaletteServiceClient pclient = new PaletteServiceClient();
			string json = pclient.GetPaletteSuggestion();
			List<PaletteContract> list = null;
			//object result = null;
			//if (json.ToLower().Contains("dataset"))
			//{
			//    DataSet ds = new DataSet();
			//    StringReader reader = new StringReader(json);
			//    ds.ReadXml(reader);
			//    result = ds;
			//}
			//else
			//{
				list = new JavaScriptSerializer().Deserialize<List<PaletteContract>>(json);

			//}

			List<PaletteContract> finallist = new List<PaletteContract>();
			List<Phrase> phraseList = new List<Phrase>();
			string div = string.Empty;

			HtmlGenericControl parentul = new HtmlGenericControl("ul");
			//parentul.Attributes.Add("class", "items");
			//<ul>
			//    <li>
			//        <ul>
			//            <li></li>
			//            <li></li>
			//            <li></li>
			//        </ul>
			//    </li>
			//    <li>
			//        <ul>
			//            <li></li>
			//            <li></li>
			//            <li></li>
			//        </ul>
			//    </li>
			//</ul>   
			string nativesentence = "";
			string learningsentence = "";
			//if (result != null)
			//{
			//    DataSet ds = (DataSet)result;

			//    LiteralControl lit = new LiteralControl();
			//    lit.Text = ds.Tables[0].Rows[0]["Sentence1"].ToString();
			//    divDisplaySuggestion.Controls.Add(lit);
			//    divSuggestion.Controls.Add(parentul);
			//    return;
			//} 

			foreach (PaletteContract paleteContract in list)
			{
				HtmlGenericControl parentli = new HtmlGenericControl("li");

				PaletteContract pcontract = new PaletteContract();
				pcontract.PaletteID = paleteContract.PaletteID;
				pcontract.SchoolID = paleteContract.SchoolID;
				pcontract.PhraseCategoryID = paleteContract.PhraseCategoryID;
				pcontract.DefaultLanguageCode = paleteContract.DefaultLanguageCode;

				HtmlGenericControl childul = new HtmlGenericControl("ul");

				var pnativelist = paleteContract.PhraseList.FindAll(x => x.LanguageCode.Equals(SessionManager.Instance.UserProfile.NativeLanguage)).OrderBy(x => x.Ordinal).ToList();
				var plearninglist = paleteContract.PhraseList.FindAll(x => x.LanguageCode.Equals(SessionManager.Instance.UserProfile.LearningLanguage)).ToList();
				var psubnativelist = paleteContract.PhraseList.FindAll(x => x.LanguageCode.Equals(SessionManager.Instance.UserProfile.SubNativeLanguage)).ToList();
				var psubnative2list = paleteContract.PhraseList.FindAll(x => x.LanguageCode.Equals(SessionManager.Instance.UserProfile.SubNativeLanguage2)).ToList();

				string words = string.Empty;
				string sentence1ordinal = "";
				string sentence2ordinal = "";
				string sounds = "";

				foreach (Phrase p in pnativelist)
				{
					nativesentence += p.Word + "&nbsp;";
					HtmlGenericControl li = new HtmlGenericControl("li");
					sounds += p.SoundFile + ",";

					string subnative2word = string.Empty;
					string subnative2code = string.Empty;

					var sub2 = psubnative2list.Find(x => x.WordMapID.Equals(p.WordMapID));

					if (sub2 != null)
					{
						subnative2word = sub2.Word;
						subnative2code = sub2.LanguageCode.Substring(0, 2);
					}

					int count = 1;
					string dimage = "data-image='../Content/images/" + p.ImageFile + "' ";
					if (string.IsNullOrEmpty(p.ImageFile))
						dimage = string.Empty;

					words = string.Format("<span id='{0}' class='firstword' data-ordinal='{1}' data-sound='{2}' data-lang='{3}' data-switchword='{4}' data-word='{5}' {6}>", "divspan" + p.PalleteID.ToString() + p.SentenceID.ToString() + p.Ordinal.ToString() + count.ToString(),
						p.Ordinal.ToString(), "../Content/Sound/" + p.SoundFile, p.LanguageCode, p.LanguageCode.Substring(0, 2) == subnative2code ? subnative2word : "", p.Word, dimage) + p.Word + "</span>" + "<br/>";
					sentence1ordinal += p.Ordinal.ToString() + ",";

					var learn = plearninglist.Find(x => x.WordMapID.Equals(p.WordMapID));
					if (learn != null)
					{
						string cl = "secondword";
						words += string.Format("<span id='{0}' class='{1}' data-ordinal='{2}' data-sound='{3}' data-lang='{4}' data-switchword='{5}' data-word='{6}' {7}>", "divspan" + learn.PalleteID.ToString() + learn.SentenceID.ToString() + p.Ordinal.ToString() + learn.Ordinal.ToString() + count.ToString(),
							cl, learn.Ordinal.ToString(), "../Content/Sound/" + learn.SoundFile, learn.LanguageCode, learn.LanguageCode.Substring(0, 2) == subnative2code ? subnative2word : "", learn.Word, dimage) + learn.Word + "</span>" + "<br/>";
						sentence2ordinal += learn.Ordinal.ToString() + ",";
						learningsentence += learn.Word + "&nbsp;";
					}
					var sub = psubnativelist.Find(x => x.WordMapID.Equals(p.WordMapID));
					if (sub != null)
					{
						string cl = "thirdword";
						words += string.Format("<span id='{0}' class='{1}' data-ordinal='{2}'>", "divspan" + sub.PalleteID.ToString() + sub.SentenceID.ToString() + p.Ordinal.ToString() + sub.Ordinal.ToString() + count.ToString(),
						   cl, sub.Ordinal.ToString()) + sub.Word + "</span>" + "<br/>";
					}

					string dataimage = "data-image='../Content/images/" + p.ImageFile + "' ";
					//string datasound = "<span id='sound' class='mp3'>"+ "http://localhost:50835/Content/images/" + p.ImageFile + "</span>'"; 
					string datasound = string.Empty;
					if( learn != null )
						datasound = "data-sound='../Content/sound/" + learn.SoundFile + "' ";

					string cssclass = "class='screenshot'";
					//string datagrouping = "data-elementgrouping='sentence_" + p.SentenceID.ToString() + "'";
					if (string.IsNullOrEmpty(p.ImageFile))
					{
						cssclass = string.Empty;
						dataimage = string.Empty;
					}
					div = string.Format("<div id=\"div{0}\" class=\"suggestion\" style=\"border:1px solid black;text-align:center; display:inline-block;background-color:white;cursor:pointer;padding-left:10px;padding-bottom:2px;\" data-isword=\"false\" ondblclick='worddblClick(\"div{0}\")'  onclick=\"wordClick('div{0}', true);\" {3} {4}>" +
					(p.ImageFile.Length > 0 ? "<a class='gallery' href='../Content/Images/" + p.ImageFile + "'> <img class='imgPicture' src=\"../Images/showimage.png\" style=\"width:15px; height:15px; left:0;\" onclick='ShowPicture(event)'/></a>" : string.Empty) +
					"<img class='imgsequence' src=\"../Images/orderedList{1}.png\" style=\"width:20px; height:20px; float:right;\"/>" +
					"{2}" +
					"</div>", p.PalleteID.ToString() + p.SentenceID.ToString() + p.Ordinal.ToString(), p.Ordinal.ToString(), words, dataimage, datasound);

					li.InnerHtml = div;

					childul.Controls.Add(li);
				}

				childul.Attributes.Add("data-sentence1Ordinal", sentence1ordinal);
				childul.Attributes.Add("data-sentence2Ordinal", sentence2ordinal);

				//parentli.Attributes.Add("class", "pallete");
				parentli.Controls.Add(childul);
				parentul.Controls.Add(parentli);
			}

			LiteralControl lit = new LiteralControl();
			lit.Text = nativesentence;
			divDisplaySuggestion.Controls.Add(lit);
			divSuggestion.Controls.Add(parentul);

			StringBuilder builder = new StringBuilder();
			builder.AppendLine("$(function ()");
			builder.AppendLine("{");
			//builder.AppendLine("$('ul.items').easyPaginate({step:5});");
			//builder.AppendLine("$('.sortable').sortable().disableSelection();;HideShowWords('#" + chkNative.ClientID + "', '.firstword'); HideShowWords('#chkSecondary', '.thirdword'); SetPalleteSelectable();");
			builder.AppendLine("HideShowWords('#" + chkNative.ClientID + "', '.firstword'); HideShowWords('#chkSecondary', '.thirdword'); SetPalleteSelectable();");
			//builder.AppendLine("$('.sortable').sortable();HideShowWords('#chkNative', '.secondword'); HideShowWords('#chkSecondary', '.thirdword'); screenshotPreview();SetPalleteSelectable();");
			builder.AppendLine("});");

			ScriptManager.RegisterStartupScript(this, this.GetType(), "CreateSuggestion", builder.ToString(), true);


		}
		private int CreatePalleteList()
		{

			
			PaletteServiceClient pclient = new PaletteServiceClient();
			SearchDTO dto = null;
			//this.Keyword = hdnKeywords.Value;

			//if (rdoCriteriaList.SelectedValue == "1") //Word
			//{

			//    dto = new SearchDTO()
			//    {
			//        SchoolID = SessionManager.Instance.UserProfile.SchoolID,
			//        CategoryID = Convert.ToInt32(ddlCategory.SelectedValue),
			//        Keyword = string.Empty, //string.IsNullOrEmpty(txtSearchSentence.Text) ? string.Empty : string.Empty ,
			//        LevelID = SessionManager.Instance.UserProfile.LevelID,
			//        PageNumber = Convert.ToInt32(hdnsentencepage.Value),
			//        RowsPerPage = m_SentenceRowPerPage
			//    };
			//}
			//else //Phrase+word
			//{
			//    dto = new SearchDTO()
			//    {
			//        SchoolID = SessionManager.Instance.UserProfile.SchoolID,
			//        CategoryID = Convert.ToInt32(ddlCategory.SelectedValue),
			//        Keyword = txtSearchSentence.Text,
			//        LevelID = SessionManager.Instance.UserProfile.LevelID,
			//        PageNumber = Convert.ToInt32(hdnsentencepage.Value),
			//        RowsPerPage = m_SentenceRowPerPage
			//    };
			//}
			//if (!string.IsNullOrEmpty(this.Keyword ) && string.IsNullOrEmpty(txtSearchSentence.Text) && ddlCategory.SelectedIndex == 0 )
			//    dto.Keyword = this.Keyword; 

			dto = new SearchDTO()
			{
				SchoolID = SessionManager.Instance.UserProfile.SchoolID,
				CategoryID = txtSearchSentence.Text.Length == 0 ? Convert.ToInt32(hdnCategory.Value) : 0,
                Word = txtSearchSentence.Text,//string.IsNullOrEmpty(txtSearchSentence.Text) ? string.Empty : string.Empty,
				Keyword = txtSearchSentence.Text,//string.IsNullOrEmpty(txtSearchSentence.Text) ? string.Empty : string.Empty,
				LevelID = SessionManager.Instance.UserProfile.LevelID,
				PageNumber = Convert.ToInt32(hdnsentencepage.Value),
				RowsPerPage = m_SentenceRowPerPage,
				TopCategoryHeaderID = txtSearchSentence.Text.Length == 0 ? Convert.ToInt32(hdnTopCategory.Value) : 0,
                TopCategoryName = hdnTopCategoryName.Value,
                UserID = SessionManager.Instance.UserProfile.UserID 
				//TopCategoryHeaderID = Convert.ToInt32(ddlCategory.SelectedValue) == 0 ? Convert.ToInt32(ddlTopCategory.SelectedValue) : 0
			};

            //if (!SessionManager.Instance.UserProfile.IsDemo)
            //{
			if (!string.IsNullOrEmpty(this.Keyword) && string.IsNullOrEmpty(txtSearchSentence.Text) && hdnCategory.Value == "0")
			{
				hdnCategory.Value = "0";
				dto.CategoryID = 0;
				if( !m_IsCategoryTriggered )
					dto.Keyword = this.Keyword.Replace("&#39;", "'");
			}
			//}
			int virtualcount = 0;
            if(IsSearchFromHistory)
            {
                dto = GetSearchSentenceDto();
                hdnsentencepage.Value = dto.PageNumber.ToString();
                hdnTopCategory.Value = dto.TopCategoryHeaderID.ToString();
                hdnCategory.Value = dto.CategoryID.ToString();
                m_SearchText = dto.Word;
                hdnTopCategoryName.Value = dto.TopCategoryName;                
            }
            else
            {
                AddSearchSentenceList(dto);
            }
            
			List < PaletteContract > list = pclient.Search(dto, out virtualcount).ToList();
			

			List<PaletteContract> finallist = new List<PaletteContract>();
			List<Phrase> phraseList = new List<Phrase>();
			string div = string.Empty;

			HtmlGenericControl parentul = new HtmlGenericControl("ul");
			parentul.Attributes.Add("class", "items");
			//<ul>
			//    <li>
			//        <ul>
			//            <li></li>
			//            <li></li>
			//            <li></li>
			//        </ul>
			//    </li>
			//    <li>
			//        <ul>
			//            <li></li>
			//            <li></li>
			//            <li></li>
			//        </ul>
			//    </li>
			//</ul>   
			foreach (PaletteContract paleteContract in list)
			{
				HtmlGenericControl parentli = new HtmlGenericControl("li");

				PaletteContract pcontract = new PaletteContract();
				pcontract.PaletteID = paleteContract.PaletteID;
				pcontract.SchoolID = paleteContract.SchoolID;
				pcontract.PhraseCategoryID = paleteContract.PhraseCategoryID;
				pcontract.DefaultLanguageCode = paleteContract.DefaultLanguageCode;

				HtmlGenericControl childul = new HtmlGenericControl("ul");


				var pnativelist = paleteContract.PhraseList.FindAll(x => x.LanguageCode.Equals(SessionManager.Instance.UserProfile.NativeLanguage)).OrderBy(x => x.Ordinal).ToList();
				var plearninglist = paleteContract.PhraseList.FindAll(x => x.LanguageCode.Equals(SessionManager.Instance.UserProfile.LearningLanguage)).ToList();
				var psubnativelist = paleteContract.PhraseList.FindAll(x => x.LanguageCode.Equals(SessionManager.Instance.UserProfile.SubNativeLanguage)).ToList();
				var psubnative2list = paleteContract.PhraseList.FindAll(x => x.LanguageCode.Equals(SessionManager.Instance.UserProfile.SubNativeLanguage2)).ToList();
				if (pnativelist != null && pnativelist.Count == 0)
					continue;
				//var pfakelist = paleteContract.PhraseList.FindAll(x => x.LanguageCode.Equals(SessionManager.Instance.UserProfile.LearningLanguage)).OrderBy(x => x.Ordinal).ToList();
				
				string words = string.Empty;
				string sentence1ordinal = "";
				string sentence2ordinal = "";
				string sounds = "";
				long sentenceid = 0;
				foreach (Phrase p in pnativelist)
				{
					var sk = paleteContract.SentenceList.Find(x => x.PaletteID.Equals(paleteContract.PaletteID) && !string.IsNullOrEmpty(x.Keyword));

					HtmlGenericControl li = new HtmlGenericControl("li");
					sounds += p.SoundFile + ",";
					int count = 1;
					string subnative2word = string.Empty;
					string subnative2code = string.Empty;

					var sub2 = psubnative2list.Find(x => x.WordMapID.Equals(p.WordMapID));

					if (sub2 != null)
					{
						subnative2word = sub2.Word;
						subnative2code = sub2.LanguageCode.Substring(0,2);
					}
					var learn = plearninglist.Find(x => x.WordMapID.Equals(p.WordMapID));
					string wordsoundfile = string.Empty;
					if (learn != null)
					{
						wordsoundfile = learn.SoundFile;
					}
					//"data-image='../Content/images/" + p.ImageFile + "' "
					string dimage = "data-image='../Content/images/" + p.ImageFile + "' ";
					if (string.IsNullOrEmpty(p.ImageFile))
						dimage = string.Empty;
					words = string.Format("<span id='{0}' class='firstword' data-ordinal='{1}' data-sound='{2}' data-lang='{3}' data-switchword='{4}' data-word='{5}' {6}, data-keyword='{7}'>", "divspan" + p.PalleteID.ToString() + p.SentenceID.ToString() + p.Ordinal.ToString() + count.ToString(),
						p.Ordinal.ToString(), "../Content/Sound/" + wordsoundfile, p.LanguageCode, p.LanguageCode.Substring(0, 2) == subnative2code ? subnative2word : "", p.Word, dimage, sk != null ? sk.Keyword.Replace("'", "&#39;") : "") + p.Word + "</span>" + "<br/>";
					sentence1ordinal += p.Ordinal.ToString() + ",";

					//var learn = plearninglist.Find(x => x.WordMapID.Equals(p.WordMapID));
					if (learn != null)
					{
						string cl = "secondword";
						words += string.Format("<span id='{0}' class='{1}' data-ordinal='{2}' data-sound='{3}' data-lang='{4}' data-switchword='{5}' data-word='{6}' {7}, data-keyword='{8}'>", "divspan" + learn.PalleteID.ToString() + learn.SentenceID.ToString() + p.Ordinal.ToString() + learn.Ordinal.ToString() + count.ToString(),
							cl, learn.Ordinal.ToString(), "../Content/Sound/" + p == null ? string.Empty : p.SoundFile, learn.LanguageCode, learn.LanguageCode.Substring(0, 2) == subnative2code ? subnative2word : "", learn.Word, dimage, sk != null ? sk.Keyword.Replace("'", "&#39;") : "") + learn.Word + "</span>" + "<br/>";
						sentence2ordinal += learn.Ordinal.ToString() + ",";
					}
					var sub = psubnativelist.Find(x => x.WordMapID.Equals(p.WordMapID));
					if (sub != null)
					{
						string cl = "thirdword";
						words += string.Format("<span id='{0}' class='{1}' data-ordinal='{2}'>", "divspan" + sub.PalleteID.ToString() + sub.SentenceID.ToString() + p.Ordinal.ToString() + sub.Ordinal.ToString() + count.ToString(),
						   cl, sub.Ordinal.ToString()) + sub.Word + "</span>" + "<br/>";
					}

					foreach (string lang in SessionManager.Instance.UserProfile.OtherLanguages)
					{
						
						var otherlanguage = paleteContract.PhraseList.FindAll(x => x.LanguageCode.Equals(lang)).ToList();
						if (otherlanguage != null)
						{
							if (learn == null)
								learn = p;

							var otherword = otherlanguage.Find(x => x.WordMapID.Equals(learn == null ? p.WordMapID : learn.WordMapID));
							if (otherword != null)
							{

								string cl = "otherword";
								words += string.Format("<span id='{0}' style='display:none;' class='{1}' data-ordinal='{2}' data-sound='{3}' data-lang='{4}' data-switchword='{5}' data-word='{6}' {7}>", "divspan" + learn.PalleteID.ToString() + learn.SentenceID.ToString() + p.Ordinal.ToString() + learn.Ordinal.ToString() + otherword.Ordinal.ToString() + count.ToString(),
									cl, otherword.Ordinal.ToString(), "../Content/Sound/" + otherword.SoundFile, otherword.LanguageCode, "", otherword.Word, dimage, sk != null ? sk.Keyword.Replace("'", "&#39;") : "") + otherword.Word + "</span>";
								//sentence2ordinal += otherword.Ordinal.ToString() + ",";
							}

						}
					}

					//if (sub2 != null)
					//{
					//    string cl = "fourthword";
					//    words += string.Format("<span id='{0}' class='{1}' data-ordinal='{2}' style='display:none;left:-1000px;top:-1000px;position:absolute;'>", "divspan" + sub2.PalleteID.ToString() + sub2.SentenceID.ToString() + p.Ordinal.ToString() + sub2.Ordinal.ToString() + count.ToString(),
					//       cl, sub2.Ordinal.ToString()) + sub2.Word + "</span>" + "<br/>";
					//}

					//var fake = pfakelist.Find(x => x.WordMapID.Equals(learn.WordMapID));
					//if (fake != null)
					//{
					//    string cl = "fakewords";
					//    words += string.Format("<span id='{0}' class='{1}' data-ordinal='{2}' data-sound='{3}' style='display:none;'>", "divspan" + fake.PalleteID.ToString() + fake.SentenceID.ToString() + p.Ordinal.ToString() + learn.Ordinal.ToString() + count.ToString(),
					//        cl, fake.Ordinal.ToString(), "../Content/Sound/" + p.SoundFile) + p.Word + "</span>" + "<br/>";
					//}



					string dataimage = "data-image='../Content/images/" + p.ImageFile + "' ";
					//string datasound = "<span id='sound' class='mp3'>"+ "http://localhost:50835/Content/images/" + p.ImageFile + "</span>'"; 
					string datasound = string.Empty;
					if( learn != null )
						datasound = "data-sound='../Content/sound/" + learn.SoundFile + "' ";

					string cssclass = "class='screenshot'";
					string datagrouping = "data-elementgrouping='sentence_" + p.SentenceID.ToString() + "'";
					if (string.IsNullOrEmpty(p.ImageFile))
					{
						cssclass = string.Empty;
						dataimage = string.Empty;
					}
					string imagesequence = "<img class='imgsequence' src=\"../Images/orderedList{1}.png\" style=\"width:20px; height:20px; position:absolute;top:-5px;right:-5px;\"/>";
					if (SessionManager.Instance.UserProfile.NativeLanguage == "ja-JP")
					{
						imagesequence = "<img class='imgsequence' src=\"../Images/red{1}.png\" style=\"width:20px; height:20px; position:absolute;top:-5px;right:-5px;\"/>";
					}

					div = string.Format("<div class='wordContainer' id=\"div{0}\" {4} style=\"border:1px solid black;text-align:center; display:inline-block;background-color:white;cursor:pointer;padding-left:10px;padding-bottom:2px;position:relative;\" data-isword=\"false\" onclick=\"wordClick('div{0}', true, true);\" {3} {5} {6}>" +
					(p.ImageFile.Length > 0 ? "<a class='gallery' href='../Content/Images/" + p.ImageFile + "'> <img class='imgPicture' src=\"../Images/showimage.png\" style=\"width:15px; height:15px; position:absolute;top:-5px;left:-5px;\" onclick='ShowPicture(event)'/></a>" : string.Empty) +
					imagesequence +
					"{2}" +
					"</div>", p.PalleteID.ToString() + p.SentenceID.ToString() + p.Ordinal.ToString(), p.Ordinal.ToString(), words, dataimage, cssclass, datasound, datagrouping);
					//"<span style='float:right;'><img class='imgsequence' src=\"../Images/orderedList{1}.png\" style=\"width:20px; height:20px; float:right;\" onclick=\"alert('bong');\"/><span>" +
					li.Attributes.Add("data-ordinalNative", p.Ordinal.ToString());

					li.Attributes.Add("data-ordinalLearning", learn != null ? learn.Ordinal.ToString() : "0");
					li.InnerHtml = div;
				
	
					childul.Controls.Add(li);
					sentenceid = p.SentenceID;
				}

				string soundfile = string.Empty;

				var sentence = paleteContract.SentenceList.Find(x => x.LanguageCode.Equals(SessionManager.Instance.UserProfile.LearningLanguage) && x.PaletteID.Equals(paleteContract.PaletteID));

				//var sentence = paleteContract.SentenceList.Find(x => x.SentenceID.Equals(sentenceid));

				if (sentence != null)
				{
					soundfile = sentence.SoundFile;
				}

				LiteralControl sound = new LiteralControl();
				sound.Text = "<img src=\"../Images/ICO_Speaker.png\" class=\"soundicon\" style=\"width:16px; height:16px; float:right;vertical-align:middle;cursor:pointer;\" onclick=\"playsoundnow(this,'" + soundfile + "');\" />";
				if( soundfile.Length > 0  )
					childul.Controls.Add(sound);

				childul.Attributes.Add("data-sentence1Ordinal", sentence1ordinal);
				childul.Attributes.Add("data-sentence2Ordinal", sentence2ordinal);
				childul.Attributes.Add("style", "padding:0px;");

				parentli.Attributes.Add("class", "pallete");
				
				parentli.Controls.Add(childul);
				parentul.Controls.Add(parentli);
			}


			sentenceContainer.Controls.Add(parentul);
			hdnOtherLanguageCode.Value = new JavaScriptSerializer().Serialize(SessionManager.Instance.UserProfile.OtherLanguages);
			return virtualcount;

		}
		

		protected void imgSearchSentence_Click(object sender, ImageClickEventArgs e)
		{
            //DataTable dt = new DataTable();
            //dt.Columns.Add(new DataColumn("name1", typeof(string)));
            //dt.Columns.Add(new DataColumn("name2", typeof(string)));
            //for (int i = 0; i < 10; i++)
            //{
            //    DataRow row = dt.NewRow();
            //    row["name1"] = "bong" + i.ToString();
            //    row["name2"] = "bong" + (i*2).ToString();
            //    dt.Rows.Add(row);
            //}
            //Repeater1.DataSource = dt;
            //Repeater1.DataBind();



            //if (rdoCriteriaList.SelectedValue == "0")//All
            //{
            //}
            //else if (rdoCriteriaList.SelectedValue == "1")//Word
            //{
            //    UpdatePanel2.Triggers.Clear();//.RemoveAt(0);
            //    SearchWords();
            //SearchSentence();
            //}
            m_IsSearchAll = true;

            hdnwordpage.Value = "1";
		    hdnsentencepage.Value = "1";
            SearchAll();
			ScriptManager.RegisterStartupScript(this, this.GetType(), "addallwords_" + Guid.NewGuid().ToString().Replace("-", ""), "AppendCircleButton();", true);
			//UpdatePanel1.Update();
		}

		private void SearchSentence()
		{
			int virtualcount = CreatePalleteList();
			int numberofpages = virtualcount / m_SentenceRowPerPage;
			if (virtualcount % m_SentenceRowPerPage > 0)
				numberofpages++;

			if (numberofpages <= 0)
				numberofpages = 0;

			//if (numberofpages <= m_SentenceRowPerPage)
			//    numberofpages = 0;
			StringBuilder builder = new StringBuilder();
			builder.AppendLine("$(function ()");
			builder.AppendLine("{");
			//builder.AppendLine("$('ul.items').easyPaginate({step:5});");
			string switchlanguageorder = "";// "SwitchLanguageOrder('.chkLanguageOrder');";
			if (SessionManager.Instance.UserProfile.NativeLanguage == "en-US")
				switchlanguageorder = "";

			//builder.AppendLine("HideShowWords('#" + chkNative.ClientID + "', '.firstword'); HideShowWords('#chkSecondary', '.thirdword'); SetPalleteSelectable(); HideShowSequence('#" + chkSequence.ClientID + "');SwitchLanguageOrder('.chkLanguageOrder');SwitchWords('.chkSubLanguage2');HideSequence();");
			//builder.AppendLine("$('.sortable').sortable();HideShowWords('#chkNative', '.secondword'); HideShowWords('#chkSecondary', '.thirdword'); screenshotPreview();SetPalleteSelectable();");
            builder.AppendLine("HideShowWords('#" + chkNative.ClientID + "', '.firstword'); HideShowWords('#chkSecondary', '.thirdword'); SetPalleteSelectable(); HideShowSequence('#" + chkSequence.ClientID + "');SwitchLanguageOrder('.chkLanguageOrder');SwitchWords('.chkSubLanguage2');ShowHidePaletteContainer(true)");
			int pagenumber = Convert.ToInt32(hdnsentencepage.Value);

            builder.AppendFormat("InitializeSwipe(); ActivateSentencePaging({0},{1}, {2});", (pagenumber > numberofpages ? "0" : pagenumber.ToString()), numberofpages.ToString(), IsPostBack.ToString().ToLower()); ;
			builder.AppendLine("});");

			ScriptManager.RegisterStartupScript(this, this.GetType(), "CreatePalleteList", builder.ToString(), true);
            UpdatePanel2.Update();
		}


		private void SearchWords()
		{
			int virtualcount = CreateWordList();
			int numberofpages = virtualcount / m_WordRowPerPage;
			if (virtualcount % m_WordRowPerPage > 0)
				numberofpages++;

			if (numberofpages <= 0)
			   numberofpages = 0;
			StringBuilder builder = new StringBuilder();
			builder.Clear();
			builder.AppendLine("$(function ()");
			builder.AppendLine("{");
			//builder.AppendLine("$('ul.items2').easyPaginate({step:2});");
			builder.AppendLine("HideShowWords('#" + chkNative.ClientID + "', '.firstword'); HideShowWords('#chkSecondary', '.thirdword'); HideShowSequence('#" + chkSequence.ClientID + "');");
			int pagenumber = Convert.ToInt32(hdnwordpage.Value);
            builder.AppendFormat("InitializeSwipe(); ActivateWordPaging({0},{1}, {2});", (pagenumber > numberofpages ? "0" : pagenumber.ToString()), numberofpages.ToString(), IsPostBack.ToString().ToLower()); ;
			builder.AppendLine("});");
			ScriptManager.RegisterStartupScript(this, this.GetType(), "CreateWordList", builder.ToString(), true);
			UpdatePanel1.Update();

		}

		//protected void imgSearchWord_Click(object sender, ImageClickEventArgs e)
		//{
		//    //System.Threading.Thread.Sleep(2000);
		//    CreateWordList();
		//    StringBuilder builder = new StringBuilder();
		//    builder.AppendLine("$(function ()");
		//    builder.AppendLine("{");
		//    builder.AppendLine("$('ul.items2').easyPaginate({step:2});");
		//    builder.AppendLine("HideShowWords('#chkNative', '.secondword'); HideShowWords('#chkSecondary', '.thirdword');" );
		//    builder.AppendLine("});");
		//    ScriptManager.RegisterStartupScript(this, this.GetType(), "testets", builder.ToString(), true);
		//    UpdatePanel2.Update();
		//}

		protected void btnSend_Click(object sender, EventArgs e)
		{
			try
			{

				SendToGroup();

				//string learningsentence = hdnLearning.Value;
				//string nativesentence = hdnNative.Value;

				//string[] ls = learningsentence.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
				//string[] ns = nativesentence.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);

			   

				//UserMessageContract umc = new UserMessageContract();
				//for (int i = 0; i < ls.Count(); i++)
				//{
				
				//    umc.SenderID = SessionManager.Instance.UserProfile.UserID;
				//    umc.RecepientID = !string.IsNullOrEmpty(Request.QueryString["to"]) ? Convert.ToInt64(Request.QueryString["to"]) : 0;
				//    umc.LearningLanguageMessage += Server.HtmlEncode(ls[i] + "<br/>");
				//    umc.NativeLanguageMessage += Server.HtmlEncode(ns[i] + "<br/>");
				//    umc.Subject = txtSubject.Text;
					
				//}

				//UserClient client = new UserClient();
				//string json = new JavaScriptSerializer().Serialize(umc);
				//bool saved = client.SaveMessage(json);
				//if (saved)
				//{
				//    Response.Redirect("MailBox");
				//}
				
				
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		private void SendToGroup()
		{
			btnSend.Enabled = false;
			string learningsentence = hdnLearning.Value;
			string nativesentence = hdnNative.Value;
			bool isDirectReply = string.IsNullOrEmpty(Request.QueryString["dr"]) ? false : true;
			List<OtherMessage> othermessages = new JavaScriptSerializer().Deserialize<List<OtherMessage>>(hdnOtherLanguagesContent.Value.Replace("\\","/"));

			string[] ls = learningsentence.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
			string[] ns = nativesentence.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
			string[] oll;
			string[] oln;
			
			Hashtable ht = new Hashtable();
			int sentencecountls = 1;
			int sentencecountns = 1;

			foreach (var s in ls)
			{
				if (ht.Contains(s))
				{
					sentencecountls++;
					continue;
				}
				ht.Add(s,s);
			}
			foreach (var s in ns)
			{
				if (ht.Contains(s))
				{
					sentencecountns++;
					continue;
				}
				ht.Add(s, s);
			}
			//---------------------
			string learningfree = hdnFreeMessage1.Value;
			string nativefree = hdnFreeMessage2.Value;


			string[] freels = learningfree.Split(new char[] { '|', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
			string[] freens = nativefree.Split(new char[] { '|', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

			bool islsInvalid = false;
			bool isnsInvalid = false;
			int invalidlsCharCount = 0;
			int invalidnsCharCount = 0;

			//List<string> excludelList =
			//    ConfigurationManager.AppSettings["ExcludeWordForRejection"].Split(new char[] { ',' },
			//        StringSplitOptions.RemoveEmptyEntries).ToList();

			if (SessionManager.Instance.UserProfile.NativeLanguage != "en-US")
			{
				ht = new Hashtable();
				foreach (var s in freels)
				{
					if (s.Length > 20 && !s.Contains(" "))
					{
						islsInvalid = true;
						break;
					}
					if (!s.Contains(" ") && s.Length > 10)
					{
						isnsInvalid = true;
						break;
					}
					if (ht.Contains(s))
					{
						sentencecountls++;
						continue;
					}
					ht.Add(s, s);

					foreach (var c in s.ToCharArray())
					{
						if (!Char.IsLetterOrDigit(c) && !Char.IsWhiteSpace(c))
							invalidlsCharCount++;
					}

				}
			}
			else if (SessionManager.Instance.UserProfile.NativeLanguage == "en-US")
			{
				ht = new Hashtable();
				foreach (var s in freens)
				{
					if (s.Length > 20 && !s.Contains(" "))
					{
						islsInvalid = true;
						break;
					}
					if (!s.Contains(" ") && s.Length > 10)
					{
						isnsInvalid = true;
						break;
					}
					if (ht.Contains(s))
					{
						sentencecountls++;
						continue;
					}
					ht.Add(s, s);
					foreach (var c in s.ToCharArray())
					{
						if (!Char.IsLetterOrDigit(c) && !Char.IsWhiteSpace(c))
							invalidnsCharCount++;
					}
				}
			}

			//---------------

			List<UserMessageContract> msgList = new List<UserMessageContract>();
			List<long> userids = new List<long>();
			string userto = string.Empty;
			if (ViewState["UserTo"] != null)
			{
				userto = ViewState["UserTo"].ToString();
				userids = userto.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(long.Parse).ToList();
			}
			else
			{
				userids.Add(!string.IsNullOrEmpty(Request.QueryString["to"]) ? Convert.ToInt64(Request.QueryString["to"]) : 0);
				userto = userids[0].ToString();
			}

			List<long> removeduserids = new List<long>();
			removeduserids = hdnRemovedUsers.Value.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(long.Parse).ToList();

			userids.RemoveAll(x => removeduserids.Contains(x));

			List<UserContract> list = new List<UserContract>();
			if (userids.Count > 0)
			{
			    string uids = string.Join(",", userids.Select(x => x.ToString()).ToArray());
				list = GetUserDetails(uids);
			}
			
			//foreach (int userid in userids)
			foreach (UserContract user in list)
			{
				UserMessageContract umc = new UserMessageContract();
				oll = othermessages.Find(x => x.LanguageCode == user.LearningLanguage).Message.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
				oln = othermessages.Find(x => x.LanguageCode == user.NativeLanguage).Message.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);

				for (int i = 0; i < ls.Count(); i++)
				{

					umc.SenderID = SessionManager.Instance.UserProfile.UserID;
					umc.RecepientID = user.UserID;
					umc.LearningLanguageMessage += "<div class='paletteContainer'>" + Server.HtmlEncode(ls[i] + "</div>");
					umc.NativeLanguageMessage += "<div class='paletteContainer'>" + Server.HtmlEncode(ns[i] + "</div>");
                    //umc.LearningLanguageMessageRecepient += oln.Length > 0 && i < oln.Length ? "<div class='paletteContainer'>" + HttpUtility.HtmlEncode(oln[i] + "</div>") : string.Empty;
                    //umc.NativeLanguageMessageRecepient += oll.Length > 0 && i < oll.Length ? "<div class='paletteContainer'>" + HttpUtility.HtmlEncode(oll[i] + "</div>") : string.Empty;
                    umc.LearningLanguageMessageRecepient += oll.Length > 0 && i < oll.Length ? "<div class='paletteContainer'>" + HttpUtility.HtmlEncode(oll[i] + "</div>") : string.Empty;
                    umc.NativeLanguageMessageRecepient += oln.Length > 0 && i < oln.Length ? "<div class='paletteContainer'>" + HttpUtility.HtmlEncode(oln[i] + "</div>") : string.Empty; 
                    umc.Keyword = hdnKeywords.Value;
					umc.IsFromNewFriends = !string.IsNullOrEmpty(Request.QueryString["grp"]) || (!string.IsNullOrEmpty(Request.QueryString["du"]) && Request.QueryString["du"] == "1");
					umc.NeedResponse = SessionManager.Instance.UserProfile.IsDemo; 
					//umc.Subject = txtSubject.Text;
					umc.IsDirectReply = isDirectReply;
					umc.IsRejected = sentencecountls > 3 || sentencecountns > 3 || islsInvalid || isnsInvalid || invalidnsCharCount >= 10 || invalidlsCharCount >= 10 ? true : false;
				}

				msgList.Add(umc);
			}
			//string s = Utility.SerializeObjectToXML(msgList);

			UserClient client = new UserClient();
			string json = new JavaScriptSerializer().Serialize(msgList);
			long[] ids = client.SaveMessage(json);
			if (ids != null)
			{
				SaveFreeMessage();
				if (sentencecountls > 3 || sentencecountns > 3 || islsInvalid || isnsInvalid || invalidnsCharCount >= 10 || invalidlsCharCount >= 10)
				{
					ScriptManager.RegisterStartupScript(this, this.GetType(), "AlertRejection", "RejectMessage(" + SessionManager.Instance.UserProfile.IsDemo.ToString().ToLower() + ");", true);
				}
				else
				{
					Response.Redirect("MailBox?d=" + SessionManager.Instance.UserProfile.IsDemo);    
				}
				
			}
			
		}

		private void SaveFreeMessage()
		{
			string learningsentence = hdnFreeMessage1.Value;
			string nativesentence = hdnFreeMessage2.Value;


			string[] ls = learningsentence.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
			string[] ns = nativesentence.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);

			List<FreeMessageContract> msgList = new List<FreeMessageContract>();
			
			for (int i = 0; i < ls.Count(); i++)
			{
				FreeMessageContract umc = new FreeMessageContract();
				umc.SenderID = SessionManager.Instance.UserProfile.UserID;
				umc.FreeMessageText1 = ls.Count() > 0 ? Server.HtmlEncode(ls[i]) : string.Empty;
				umc.FreeMessageText2 = ns.Count() > 0 ? Server.HtmlEncode(ns[i]) : string.Empty;
				umc.SchoolID = SessionManager.Instance.UserProfile.SchoolID;
				msgList.Add(umc);
			}


			UserClient client = new UserClient();
			
			bool success = client.InsertFreeMessage(msgList.ToArray());
		}

		protected void btnSearchSentence_Click(object sender, EventArgs e)
		{
			try
			{
                
                if (!string.IsNullOrEmpty(hdnTopCategory.Value))
                {
                    var cats = CategoryList.FindAll(x => x.TopCategoryHeaderID.Equals(Convert.ToInt32(hdnTopCategory.Value)));
                    if (cats.Count > 0 && cats.Count == 1)
                    {
                        hdnCategory.Value = cats[0].PhraseCategoryID.ToString();
                    }

                }
				SearchSentence();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "addallwords_" + Guid.NewGuid().ToString().Replace("-", ""), "AppendCircleButton();ToggleSlider('items','up','show');", true);

			}
			catch (Exception ex)
			{
				
				throw ex;
			}
		}

		protected void btnSearchWord_Click(object sender, EventArgs e)
		{
			try
			{
				SearchWords();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "CreateWordList_ShowWordSlide", "ToggleSlider('items2','right','show');", true);
			}
			catch (Exception ex)
			{

				throw ex;
			}
		}

		protected void ddlTopCategory_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				//m_IsCategoryTriggered = true;
				//List<PhraseCategoryContract> list = null;
				//if (ddlTopCategory.SelectedValue == "0")
				//    list = CategoryList;
				//else
				//    list = CategoryList.Where(x => x.TopCategoryHeaderID.Equals(Convert.ToInt32(ddlTopCategory.SelectedValue))).ToList();

				//if (list != null)
				//{

				//    if (list.Find(x => x.PhraseCategoryID.Equals(0)) == null)
				//        list.Insert(0, new PhraseCategoryContract() { PhraseCategoryID = 0, PhraseCategoryCode = "[All]" });

				//    ddlCategory.DataSource = list;
				//    ddlCategory.DataTextField = "PhraseCategoryCode";
				//    ddlCategory.DataValueField = "PhraseCategoryID";
				//    ddlCategory.DataBind();

				//}
				//ddlCategory.SelectedValue = "0";
				//TriggerCategorySearch();
			}
			catch (Exception)
			{
				throw;
			}
		}

		protected void rptTopCategory_ItemDataBound(object sender, RepeaterItemEventArgs e)
		{
			RepeaterItem item = e.Item;
			if ((item.ItemType == ListItemType.Item) || (item.ItemType == ListItemType.AlternatingItem))
			{
				TopCategoryContract top = (TopCategoryContract)item.DataItem;
				if (top != null)
				{
					List<PhraseCategoryContract> list = null;
					list = CategoryList.Where(x => x.TopCategoryHeaderID.Equals(top.TopCategoryHeaderID)).ToList();

					if (list != null)
					{
						if (list.Find(x => x.PhraseCategoryID.Equals(0)) == null && list.Count > 1)
							list.Insert(0, new PhraseCategoryContract() { PhraseCategoryID = 0, PhraseCategoryCode = "[All]" });

						Repeater rpt = (Repeater)item.FindControl("rptCategory");
						if (rpt != null && list.Count > 1)
						{
							rpt.DataSource = list;
							rpt.DataBind();
						}
					}

				}
			}
		}

		protected void btnSearchByCategory_Click(object sender, EventArgs e)
		{
			try
			{
				if (!string.IsNullOrEmpty(hdnTopCategory.Value))
				{
					var cats = CategoryList.FindAll(x => x.TopCategoryHeaderID.Equals(Convert.ToInt32(hdnTopCategory.Value)));
					if (cats.Count > 0 && cats.Count == 1)
					{
						hdnCategory.Value = cats[0].PhraseCategoryID.ToString(); 
					}

				}
				TriggerCategorySearch();
			}
			catch (Exception ex)
			{
				throw ex;
			}
			
		}
		
		private List<UserContract> GetUserDetails(string usertos)
		{
			List<UserContract> list = new List<UserContract>();
			list = new List<UserContract>(usertos.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(s => new UserContract() { UserID = int.Parse(s) }));
			UserContract[] usl = new UserClient().GetUserByIDs(list.ToArray());

			return usl.ToList();
		}

        private void AddSearchSentenceList(SearchDTO item)
        {
            SentenceSearchHistoryList.Add(item);
            if (SentenceSearchHistoryList.Count > m_SearchHistoryLimit)
            {
                SentenceSearchHistoryList.RemoveAt(0);
            }

            if(!m_IsSearchAll)
            {
                if (WordSearchHistoryList.Count > 0)
                {
                    WordSearchHistoryList.Add(WordSearchHistoryList[WordSearchHistoryList.Count - 1]);
                    if (WordSearchHistoryList.Count > m_SearchHistoryLimit)
                    {
                        WordSearchHistoryList.RemoveAt(0);
                    }
                }
            }
            if (WordSearchHistoryList.Count >= 2)
            {
                imgBack.Visible = true;
                UpdatePanel3.Update();
            }

        }
        private void AddSearchWordList(SearchDTO item)
        {
            WordSearchHistoryList.Add(item);
            if (WordSearchHistoryList.Count > m_SearchHistoryLimit)
            {
                WordSearchHistoryList.RemoveAt(0);
            }

            if (!m_IsSearchAll)
            {
                if (SentenceSearchHistoryList.Count > 0)
                {
                    SentenceSearchHistoryList.Add(SentenceSearchHistoryList[SentenceSearchHistoryList.Count - 1]);
                    if (SentenceSearchHistoryList.Count > m_SearchHistoryLimit)
                    {
                        SentenceSearchHistoryList.RemoveAt(0);
                    }
                }
            }

            if (WordSearchHistoryList.Count >= 2)
            {
                imgBack.Visible = true;
                UpdatePanel3.Update();
            }
        }

        private SearchDTO GetSearchSentenceDto()
        {
            if (SentenceSearchHistoryList.Count == SentenceSearchHistoryListIndex && m_IsBack)
                SentenceSearchHistoryListIndex = SentenceSearchHistoryList.Count - 1;

            SearchDTO dto = SentenceSearchHistoryList[SentenceSearchHistoryListIndex-1];
            return dto;
        }

        private SearchDTO GetSearchWordDto()
        {
            if (SentenceSearchHistoryList.Count == SentenceSearchHistoryListIndex && m_IsBack)
                SentenceSearchHistoryListIndex = SentenceSearchHistoryList.Count - 1;

            SearchDTO dto = WordSearchHistoryList[SentenceSearchHistoryListIndex-1];
            return dto;
        }

        protected void imgBack_Click(object sender, ImageClickEventArgs e)
        {
            m_IsBack = true;
            IsSearchFromHistory = true;

            if (SentenceSearchHistoryListIndex == -1)
            {
                if(SentenceSearchHistoryList.Count == m_SearchHistoryLimit)
                    SentenceSearchHistoryListIndex = m_SearchHistoryLimit;//SentenceSearchHistoryList.Count - 1;
                else
                    SentenceSearchHistoryListIndex = SentenceSearchHistoryList.Count - 1;

                //imgForward.Visible = true;
            }
            else
                SentenceSearchHistoryListIndex--;

            if(SentenceSearchHistoryListIndex < 0)
            {
                SentenceSearchHistoryListIndex = 0;
            }
            if (SentenceSearchHistoryListIndex ==1)
            {
                imgBack.Visible = false;
            }

            imgForward.Visible = true;
            UpdatePanel3.Update();

            SearchSentence();
            SearchWords();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "InitializeCategoryscript_back",
                      string.Format("InitializeCategory('{0}');InitializeSearchText('{1}');AppendCircleButton();", hdnTopCategoryName.Value, m_SearchText
                          ),
                      true);
            
            IsSearchFromHistory = false;
        }

        protected void imgForward_Click(object sender, ImageClickEventArgs e)
        {
            m_IsBack = false;
            IsSearchFromHistory = true;
           
            if (SentenceSearchHistoryListIndex < m_SearchHistoryLimit)
            {
                SentenceSearchHistoryListIndex++;
                //imgBack.Visible = true;
            }
            else
                imgForward.Visible = false;

            if (SentenceSearchHistoryListIndex > m_SearchHistoryLimit)
                SentenceSearchHistoryListIndex = m_SearchHistoryLimit;

            if (SentenceSearchHistoryList.Count == SentenceSearchHistoryListIndex)
                imgForward.Visible = false;

            imgBack.Visible = true;
            UpdatePanel3.Update();
            SearchSentence();
            SearchWords();


            ScriptManager.RegisterStartupScript(this, this.GetType(), "InitializeCategoryscript_back",
                      string.Format("InitializeCategory('{0}');InitializeSearchText('{1}');AppendCircleButton();", hdnTopCategoryName.Value, m_SearchText
                          ),
                      true);
            IsSearchFromHistory = false;
        }

        private void SearchAll()
        {
            m_IsSearchAll = true;
            SearchWords();
            SearchSentence();
            m_IsSearchAll = false;
        }
    }
}